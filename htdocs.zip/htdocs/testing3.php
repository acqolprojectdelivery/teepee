<!DOCTYPE html>
<?php
$con = new mysqli("localhost","root","","form");
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>This is a Test</title>
<script type="text/javascript">
$(document).ready(function(){
     $("#btn1").click(function(e){
     e.preventDefault();
    });
});
</script>
</head>
<body>
<form method="post" enctype="multipart/form-data">
<table>
<tr><td><textarea  cols="20" rows="4" name="e2"></textarea></td></tr>
<tr><td><input  id="submit" type="submit" name="t1" value="save" /></td></tr>
</table>
<?php
if(isset($_POST['t1']))
{
$imgarryimp=array();
      $d="insert into form(address)values('$_POST[e2]')";
if($con->query($d)==TRUE)
    {
      echo "Your Data Saved Successfully!!!";
    }
}
exit;
?>
</form>
<table>
<?php
$t="select * from form";
$y=$con->query($t);
foreach ($y as $q);
{
?>
<tr>
<?php echo $q['address'];?>
</tr>
<?php }?>
</table>
</body>
</html>

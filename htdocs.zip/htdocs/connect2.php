<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teepee";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Open database here
// Let's pretend these values were passed by a form
$_POST['scenarios'] = "Bob Marley";
$_POST['save'] = "save";
// Insert all the values of $_POST into the database table `artists`, except
// for $_POST['submit'].  Remember, field names are determined by array keys!
$result = mysql_insert_array("scenarios", $_POST, "save");
// Results
if( $result['mysql_error'] ) {
    echo "Query Failed: " . $result['mysql_error'];
} else {
    echo "Query Succeeded! <br />";
    echo "<pre>";
    print_r($result);
    echo "</pre>";
}
// Close database
?>
<?php
include("connect1.php");
if(isset($_POST['save']))
$scenarios = mysqli_real_escape_string($con, $_POST['inputBodyBox']);
?>

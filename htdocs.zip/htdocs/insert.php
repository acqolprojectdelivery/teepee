<html>
<head>
<title>
untitled document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php
$nm=$_GET["nm"];
$city=$_GET["ct"];
$age=$_GET["age"];
mysql_connect("localhost","root","");
mysql_select_db("testing1");
mysql_query("insert into test values('$nm','$city','$age')");
?>
</body>
</html>

<!Doctype html>
<html>
<head>
<title>Connecting to a Database</title>
</head>
<body>
<?php
  $con = mysqli_connect('localhost','root','');
  $db = mysqli_select_db('testing');
  if($con)
  {
    echo 'Successfully connected to the database.';
   }
  else
   {
      die('Error.');
   }
   if($db)
    {
      echo 'Successfully found the database.';
    }
     else
    {
      die('Error. Database not found.');
    }
?>
</body>
</html>